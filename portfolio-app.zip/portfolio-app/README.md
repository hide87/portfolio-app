# 포트폴리오 앱

## 설치 및 실행

```bash
npm install
npm run dev
```

## Vercel 배포

1. GitHub에 push
2. vercel.com → New Project → import
3. Environment Variables 추가:
   - `GEMINI_API_KEY` = 새로 발급한 Gemini API 키

## 환경변수 설정 (로컬)

`.env.local` 파일에서 Gemini API 키 입력:
```
GEMINI_API_KEY=AIzaSy...
```

## 기능

- 📊 5개 계좌 통합 포트폴리오 현황
- 💱 USD/KRW 실시간 환율 + 자산 영향 계산
- 📈 TradingView 차트 (MA, 볼린저밴드, RSI)
- 📅 24개 종목 어닝 트래커
- 🤖 Gemini AI 포트폴리오 분석
- 🗺️ 테마별 히트맵

## 데이터 소스

- 시세: Yahoo Finance (무료)
- 환율: Yahoo Finance USDKRW=X
- 어닝: Yahoo Finance quoteSummary
- AI: Google Gemini 2.0 Flash (무료)
- 차트: TradingView Lightweight Charts (오픈소스)
