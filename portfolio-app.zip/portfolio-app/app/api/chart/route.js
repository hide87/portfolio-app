// app/api/chart/route.js
export async function GET(request) {
  const { searchParams } = new URL(request.url)
  const symbol = searchParams.get('symbol') || ''
  const range = searchParams.get('range') || '3mo'
  const interval = searchParams.get('interval') || '1d'

  try {
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?range=${range}&interval=${interval}&includePrePost=false`
    const res = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0' },
      next: { revalidate: 300 },
    })
    const data = await res.json()
    const chart = data?.chart?.result?.[0]
    if (!chart) throw new Error('No data')

    const timestamps = chart.timestamp || []
    const ohlcv = chart.indicators?.quote?.[0] || {}
    const closes = ohlcv.close || []
    const opens = ohlcv.open || []
    const highs = ohlcv.high || []
    const lows = ohlcv.low || []
    const volumes = ohlcv.volume || []

    const candles = timestamps.map((t, i) => ({
      time: t,
      open: opens[i],
      high: highs[i],
      low: lows[i],
      close: closes[i],
      volume: volumes[i],
    })).filter(c => c.open && c.high && c.low && c.close)

    return Response.json({ candles, meta: chart.meta })
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 })
  }
}
