// app/api/earnings/route.js
export async function GET(request) {
  const { searchParams } = new URL(request.url)
  const ticker = searchParams.get('ticker') || ''

  try {
    // Yahoo Finance earnings history
    const url = `https://query1.finance.yahoo.com/v10/finance/quoteSummary/${ticker}?modules=earnings,earningsHistory,calendarEvents`
    const res = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
      next: { revalidate: 3600 },
    })
    const data = await res.json()
    const summary = data?.quoteSummary?.result?.[0]

    const earningsHistory = summary?.earningsHistory?.history?.map(h => ({
      date: h.quarter?.fmt,
      epsActual: h.epsActual?.raw,
      epsEstimate: h.epsEstimate?.raw,
      epsDiff: h.epsDifference?.raw,
      surprisePct: h.surprisePercent?.raw,
    })) || []

    const nextEarnings = summary?.calendarEvents?.earnings
    const earningsDate = nextEarnings?.earningsDate?.[0]?.fmt || null

    const quarterlyEPS = summary?.earnings?.financialsChart?.quarterly?.map(q => ({
      date: q.date,
      actual: q.actual?.raw,
      estimate: q.estimate?.raw,
    })) || []

    return Response.json({ earningsHistory, earningsDate, quarterlyEPS })
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 })
  }
}
