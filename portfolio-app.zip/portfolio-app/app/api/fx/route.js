// app/api/fx/route.js
export async function GET() {
  try {
    // Yahoo Finance USD/KRW
    const res = await fetch(
      'https://query1.finance.yahoo.com/v7/finance/quote?symbols=USDKRW%3DX&fields=regularMarketPrice,regularMarketChangePercent',
      {
        headers: { 'User-Agent': 'Mozilla/5.0' },
        next: { revalidate: 300 },
      }
    )
    const data = await res.json()
    const quote = data?.quoteResponse?.result?.[0]
    return Response.json({
      usdkrw: quote?.regularMarketPrice || 1380,
      changePct: quote?.regularMarketChangePercent || 0,
    })
  } catch {
    return Response.json({ usdkrw: 1380, changePct: 0 })
  }
}
