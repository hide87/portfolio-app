// app/api/gemini/route.js
export async function POST(request) {
  const body = await request.json()
  const { prompt, type } = body

  const GEMINI_KEY = process.env.GEMINI_API_KEY
  if (!GEMINI_KEY) return Response.json({ error: 'No API key' }, { status: 500 })

  const systemPrompts = {
    portfolio: '당신은 전문 포트폴리오 분석가입니다. 한국어로 간결하고 인사이트 있는 분석을 제공하세요. 마크다운 형식으로 답변하세요.',
    chart: '당신은 기술적 분석 전문가입니다. 주어진 차트 데이터를 바탕으로 한국어로 핵심 분석을 제공하세요.',
    earnings: '당신은 기업 실적 분석 전문가입니다. 어닝 데이터를 분석하여 한국어로 핵심 인사이트를 제공하세요.',
  }

  try {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                { text: (systemPrompts[type] || systemPrompts.portfolio) + '\n\n' + prompt }
              ]
            }
          ],
          generationConfig: { temperature: 0.7, maxOutputTokens: 1024 },
        }),
      }
    )
    const data = await res.json()
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '분석을 가져올 수 없습니다.'
    return Response.json({ text })
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 })
  }
}
