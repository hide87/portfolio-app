'use client'
import { useState } from 'react'
import HomeTab from '@/components/HomeTab'
import PortfolioTab from '@/components/PortfolioTab'
import ChartTab from '@/components/ChartTab'
import EarningsTab from '@/components/EarningsTab'
import AITab from '@/components/AITab'
import TabBar from '@/components/TabBar'

export default function Page() {
  const [activeTab, setActiveTab] = useState('home')

  return (
    <div className="flex flex-col h-screen max-w-md mx-auto relative overflow-hidden">
      {/* 배경 그라디언트 */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-64 h-64 bg-accent/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 right-0 w-48 h-48 bg-purple-500/5 rounded-full blur-3xl" />
      </div>

      {/* 메인 콘텐츠 */}
      <main className="flex-1 overflow-y-auto pb-20">
        {activeTab === 'home' && <HomeTab onNavigate={setActiveTab} />}
        {activeTab === 'portfolio' && <PortfolioTab />}
        {activeTab === 'chart' && <ChartTab />}
        {activeTab === 'earnings' && <EarningsTab />}
        {activeTab === 'ai' && <AITab />}
      </main>

      {/* 하단 탭바 */}
      <TabBar activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  )
}
