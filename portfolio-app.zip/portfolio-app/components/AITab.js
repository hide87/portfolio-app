'use client'
import { useState } from 'react'
import { Sparkles, RefreshCw, TrendingUp, BarChart2, DollarSign } from 'lucide-react'
import { useQuotes, calcPortfolio } from '@/lib/useQuotes'
import { ACCOUNTS } from '@/lib/data'
import { fmtKRW, fmtPct } from '@/lib/fmt'

function MarkdownText({ text }) {
  if (!text) return null
  const html = text
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/^- (.+)$/gm, '<li>$1</li>')
    .replace(/(<li>.*<\/li>)/gs, '<ul>$1</ul>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/^(?!<[h|u|l])/gm, '')

  return (
    <div
      className="md-content text-sm leading-relaxed"
      dangerouslySetInnerHTML={{ __html: `<p>${html}</p>` }}
    />
  )
}

const ANALYSIS_TYPES = [
  { id: 'portfolio', label: '포트폴리오 종합', Icon: BarChart2, desc: '전체 포트폴리오 리스크/기회 분석' },
  { id: 'sector', label: '섹터 분석', Icon: TrendingUp, desc: 'AI인프라·반도체·방산 테마 전망' },
  { id: 'fx', label: '환율 영향 분석', Icon: DollarSign, desc: 'USD/KRW 변동이 자산에 미치는 영향' },
]

export default function AITab() {
  const { quotes, fx, loading: quotesLoading } = useQuotes()
  const { accountsSummary, totalKRW, totalGain, totalGainPct } = calcPortfolio(ACCOUNTS, quotes, fx)
  const [result, setResult] = useState('')
  const [analysisLoading, setAnalysisLoading] = useState(false)
  const [activeType, setActiveType] = useState(null)
  const [customQ, setCustomQ] = useState('')

  const buildPortfolioContext = () => {
    const lines = [`총 자산: ${fmtKRW(totalKRW)}원`, `총 수익률: ${fmtPct(totalGainPct)}`, `USD/KRW: ${fx.usdkrw}`, '']
    accountsSummary.forEach(acc => {
      if (acc.isCash) {
        lines.push(`[${acc.name}] 현금 ${fmtKRW(acc.totalValue)}원`)
      } else {
        lines.push(`[${acc.name}] 총 ${fmtKRW(acc.totalValue)}원 / 수익률 ${fmtPct(acc.gainPct)}`)
        acc.holdings.forEach(h => {
          lines.push(`  - ${h.name}: ${h.qty}주, ${fmtPct(h.gainPct)}, 평가 ${fmtKRW(h.currentValueKRW)}원`)
        })
      }
    })
    return lines.join('\n')
  }

  const runAnalysis = async (type) => {
    setActiveType(type.id)
    setAnalysisLoading(true)
    setResult('')

    const ctx = buildPortfolioContext()
    const prompts = {
      portfolio: `다음은 나의 투자 포트폴리오 현황입니다:\n\n${ctx}\n\n위 포트폴리오에 대해 다음을 분석해주세요:\n1. 현재 포트폴리오의 강점과 리스크\n2. 섹터 집중도 문제점\n3. 단기 주목할 종목\n4. 전반적인 의견`,
      sector: `포트폴리오 현황:\n${ctx}\n\nAI 인프라(GEV, VRT, PWR, BE), 반도체(NVDA, AVGO, SK하이닉스 등 ETF), 방산(SHLD, ITA) 세 테마에 대해:\n1. 각 테마의 현재 모멘텀\n2. 리스크 요인\n3. 향후 6개월 전망`,
      fx: `현재 USD/KRW: ${fx.usdkrw}원\n\n포트폴리오에서 해외주식(USD) 자산:\n${accountsSummary.find(a => a.id === 'super365_us')?.holdings.map(h => `${h.name}: ${fmtKRW(h.currentValueKRW)}원`).join('\n')}\n\n환율 변동이 이 포트폴리오에 미치는 영향을 분석하고, 환율 헷지 관점에서 조언해주세요.`,
    }

    try {
      const res = await fetch('/api/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: prompts[type.id], type: 'portfolio' }),
      })
      const data = await res.json()
      setResult(data.text || '분석 결과를 가져올 수 없습니다.')
    } catch {
      setResult('오류가 발생했습니다. 잠시 후 다시 시도해주세요.')
    } finally {
      setAnalysisLoading(false)
    }
  }

  const runCustom = async () => {
    if (!customQ.trim()) return
    setActiveType('custom')
    setAnalysisLoading(true)
    setResult('')

    const ctx = buildPortfolioContext()
    const prompt = `포트폴리오 현황:\n${ctx}\n\n질문: ${customQ}`

    try {
      const res = await fetch('/api/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, type: 'portfolio' }),
      })
      const data = await res.json()
      setResult(data.text || '답변을 가져올 수 없습니다.')
    } catch {
      setResult('오류가 발생했습니다.')
    } finally {
      setAnalysisLoading(false)
    }
  }

  return (
    <div className="flex flex-col gap-4 p-4 animate-fade-in">
      <div className="flex items-center gap-2 pt-2">
        <Sparkles size={20} className="text-accent" />
        <h2 className="text-lg font-semibold">AI 분석</h2>
        <span className="text-xs text-muted ml-auto">Gemini 2.0 Flash</span>
      </div>

      {/* 분석 타입 버튼 */}
      <div className="flex flex-col gap-2">
        {ANALYSIS_TYPES.map(type => (
          <button
            key={type.id}
            onClick={() => runAnalysis(type)}
            disabled={analysisLoading || quotesLoading}
            className={`card p-4 flex items-center gap-3 text-left active:scale-98 transition-all disabled:opacity-50 ${
              activeType === type.id ? 'border-accent/50 glow-accent' : ''
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center flex-shrink-0">
              <type.Icon size={18} className="text-accent" />
            </div>
            <div>
              <p className="text-sm font-semibold">{type.label}</p>
              <p className="text-xs text-muted">{type.desc}</p>
            </div>
            {activeType === type.id && analysisLoading && (
              <RefreshCw size={14} className="text-accent ml-auto animate-spin" />
            )}
          </button>
        ))}
      </div>

      {/* 커스텀 질문 */}
      <div className="card p-4 flex flex-col gap-3">
        <p className="text-sm font-medium">직접 질문하기</p>
        <textarea
          value={customQ}
          onChange={e => setCustomQ(e.target.value)}
          placeholder="예: SHLD를 지금 더 매수해야 할까요?"
          className="bg-surface border border-border rounded-xl px-3 py-2.5 text-sm resize-none outline-none focus:border-accent/50 transition-colors"
          rows={3}
        />
        <button
          onClick={runCustom}
          disabled={!customQ.trim() || analysisLoading}
          className="bg-accent text-white rounded-xl py-2.5 text-sm font-medium disabled:opacity-50 active:scale-98 transition-all"
        >
          분석 요청
        </button>
      </div>

      {/* 결과 */}
      {analysisLoading && (
        <div className="card p-6 flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-2 border-accent border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-muted">Gemini가 분석 중...</p>
        </div>
      )}

      {result && !analysisLoading && (
        <div className="card p-4 animate-slide-up">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles size={14} className="text-accent" />
            <p className="text-xs text-accent font-medium">AI 분석 결과</p>
          </div>
          <MarkdownText text={result} />
        </div>
      )}
    </div>
  )
}
