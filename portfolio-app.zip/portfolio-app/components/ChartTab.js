'use client'
import { useState, useEffect, useRef, useCallback } from 'react'
import { Search, X } from 'lucide-react'
import { EARNINGS_WATCHLIST } from '@/lib/data'

const RANGES = [
  { label: '1주', value: '5d', interval: '60m' },
  { label: '1달', value: '1mo', interval: '1d' },
  { label: '3달', value: '3mo', interval: '1d' },
  { label: '6달', value: '6mo', interval: '1d' },
  { label: '1년', value: '1y', interval: '1wk' },
]

const INDICATORS = ['MA', 'BB', 'RSI', '일목']

export default function ChartTab() {
  const [symbol, setSymbol] = useState('NVDA')
  const [searchText, setSearchText] = useState('')
  const [range, setRange] = useState(RANGES[2])
  const [indicators, setIndicators] = useState(['MA'])
  const [candles, setCandles] = useState([])
  const [loading, setLoading] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const chartRef = useRef(null)
  const chartInstance = useRef(null)
  const seriesRef = useRef({})

  const suggestions = EARNINGS_WATCHLIST.filter(w =>
    searchText && (
      w.ticker.toLowerCase().includes(searchText.toLowerCase()) ||
      w.name.toLowerCase().includes(searchText.toLowerCase())
    )
  ).slice(0, 5)

  const fetchChart = useCallback(async (sym, rng) => {
    setLoading(true)
    try {
      const res = await fetch(`/api/chart?symbol=${sym}&range=${rng.value}&interval=${rng.interval}`)
      const data = await res.json()
      setCandles(data.candles || [])
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchChart(symbol, range)
  }, [symbol, range, fetchChart])

  useEffect(() => {
    if (!chartRef.current || !candles.length) return

    const initChart = async () => {
      const { createChart, CandlestickSeries, LineSeries, HistogramSeries } = await import('lightweight-charts')

      // 기존 차트 제거
      if (chartInstance.current) {
        chartInstance.current.remove()
        chartInstance.current = null
        seriesRef.current = {}
      }

      const chart = createChart(chartRef.current, {
        width: chartRef.current.clientWidth,
        height: 320,
        layout: { background: { color: '#12121a' }, textColor: '#9ca3af' },
        grid: { vertLines: { color: '#1a1a26' }, horzLines: { color: '#1a1a26' } },
        crosshair: { mode: 1 },
        rightPriceScale: { borderColor: '#2a2a3a' },
        timeScale: { borderColor: '#2a2a3a', timeVisible: true },
      })

      chartInstance.current = chart

      // 캔들 시리즈
      const candleSeries = chart.addSeries(CandlestickSeries, {
        upColor: '#22c55e',
        downColor: '#ef4444',
        borderUpColor: '#22c55e',
        borderDownColor: '#ef4444',
        wickUpColor: '#22c55e',
        wickDownColor: '#ef4444',
      })
      candleSeries.setData(candles)
      seriesRef.current.candle = candleSeries

      // 이동평균
      if (indicators.includes('MA')) {
        const calcMA = (period) => {
          return candles.map((c, i) => {
            if (i < period - 1) return null
            const avg = candles.slice(i - period + 1, i + 1).reduce((s, x) => s + x.close, 0) / period
            return { time: c.time, value: avg }
          }).filter(Boolean)
        }

        const ma20 = chart.addSeries(LineSeries, { color: '#6366f1', lineWidth: 1.5, priceLineVisible: false, lastValueVisible: false })
        ma20.setData(calcMA(20))
        const ma60 = chart.addSeries(LineSeries, { color: '#f59e0b', lineWidth: 1.5, priceLineVisible: false, lastValueVisible: false })
        ma60.setData(calcMA(60))
      }

      // 볼린저밴드
      if (indicators.includes('BB')) {
        const period = 20
        const bbData = candles.map((c, i) => {
          if (i < period - 1) return null
          const slice = candles.slice(i - period + 1, i + 1).map(x => x.close)
          const mean = slice.reduce((a, b) => a + b, 0) / period
          const std = Math.sqrt(slice.reduce((a, b) => a + (b - mean) ** 2, 0) / period)
          return { time: c.time, upper: mean + 2 * std, middle: mean, lower: mean - 2 * std }
        }).filter(Boolean)

        const upper = chart.addSeries(LineSeries, { color: '#8b5cf680', lineWidth: 1, priceLineVisible: false, lastValueVisible: false })
        upper.setData(bbData.map(d => ({ time: d.time, value: d.upper })))
        const lower = chart.addSeries(LineSeries, { color: '#8b5cf680', lineWidth: 1, priceLineVisible: false, lastValueVisible: false })
        lower.setData(bbData.map(d => ({ time: d.time, value: d.lower })))
      }

      chart.timeScale().fitContent()

      // 리사이즈
      const ro = new ResizeObserver(() => {
        if (chartRef.current) chart.applyOptions({ width: chartRef.current.clientWidth })
      })
      ro.observe(chartRef.current)
      return () => ro.disconnect()
    }

    initChart()
  }, [candles, indicators])

  // RSI 계산 (별도 섹션)
  const rsiData = (() => {
    if (!indicators.includes('RSI') || candles.length < 15) return []
    const period = 14
    const gains = [], losses = []
    for (let i = 1; i < candles.length; i++) {
      const diff = candles[i].close - candles[i - 1].close
      gains.push(diff > 0 ? diff : 0)
      losses.push(diff < 0 ? -diff : 0)
    }
    const result = []
    for (let i = period; i < gains.length; i++) {
      const avgGain = gains.slice(i - period, i).reduce((a, b) => a + b, 0) / period
      const avgLoss = losses.slice(i - period, i).reduce((a, b) => a + b, 0) / period
      const rs = avgLoss === 0 ? 100 : avgGain / avgLoss
      result.push({ time: candles[i + 1]?.time, rsi: 100 - 100 / (1 + rs) })
    }
    return result.filter(r => r.time && r.rsi)
  })()

  const latestRSI = rsiData[rsiData.length - 1]?.rsi

  const toggleIndicator = (ind) => {
    setIndicators(prev => prev.includes(ind) ? prev.filter(i => i !== ind) : [...prev, ind])
  }

  return (
    <div className="flex flex-col gap-4 p-4 animate-fade-in">
      <h2 className="text-lg font-semibold pt-2">차트</h2>

      {/* 검색 */}
      <div className="relative">
        <div className="flex items-center gap-2 bg-surface border border-border rounded-xl px-3 py-2.5">
          <Search size={16} className="text-muted flex-shrink-0" />
          <input
            value={searchText}
            onChange={e => { setSearchText(e.target.value); setShowSuggestions(true) }}
            onFocus={() => setShowSuggestions(true)}
            placeholder="종목 검색 (NVDA, 삼성...)"
            className="bg-transparent text-sm flex-1 outline-none placeholder:text-muted"
          />
          {searchText && (
            <button onClick={() => { setSearchText(''); setShowSuggestions(false) }}>
              <X size={14} className="text-muted" />
            </button>
          )}
        </div>
        {showSuggestions && suggestions.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-1 card z-10 overflow-hidden">
            {suggestions.map(s => (
              <button
                key={s.ticker}
                onClick={() => { setSymbol(s.ticker); setSearchText(s.ticker); setShowSuggestions(false) }}
                className="w-full flex items-center justify-between px-4 py-3 text-sm hover:bg-border/30 active:bg-border/50"
              >
                <span className="font-medium">{s.name}</span>
                <span className="text-xs text-muted font-mono">{s.ticker}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 현재 종목 */}
      <div className="flex items-center justify-between">
        <p className="font-semibold">{symbol}</p>
        <div className="flex gap-1">
          {RANGES.map(r => (
            <button
              key={r.value}
              onClick={() => setRange(r)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                range.value === r.value ? 'bg-accent text-white' : 'text-muted'
              }`}
            >{r.label}</button>
          ))}
        </div>
      </div>

      {/* 인디케이터 토글 */}
      <div className="flex gap-2 flex-wrap">
        {INDICATORS.map(ind => (
          <button
            key={ind}
            onClick={() => toggleIndicator(ind)}
            className={`px-3 py-1 rounded-full text-xs font-medium border transition-all ${
              indicators.includes(ind)
                ? 'bg-accent/20 border-accent text-accent'
                : 'border-border text-muted'
            }`}
          >{ind}</button>
        ))}
      </div>

      {/* 차트 */}
      <div className="card overflow-hidden">
        {loading && (
          <div className="flex items-center justify-center h-80">
            <div className="w-8 h-8 border-2 border-accent border-t-transparent rounded-full animate-spin" />
          </div>
        )}
        <div ref={chartRef} className={loading ? 'hidden' : 'w-full'} />
      </div>

      {/* RSI 표시 */}
      {indicators.includes('RSI') && latestRSI && (
        <div className="card p-4">
          <p className="text-xs text-muted mb-2">RSI (14)</p>
          <div className="flex items-center gap-3">
            <div className="flex-1 h-2 bg-border rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${
                  latestRSI > 70 ? 'bg-down' : latestRSI < 30 ? 'bg-up' : 'bg-accent'
                }`}
                style={{ width: `${latestRSI}%` }}
              />
            </div>
            <span className={`text-sm font-bold font-num ${
              latestRSI > 70 ? 'text-down' : latestRSI < 30 ? 'text-up' : 'text-accent'
            }`}>
              {latestRSI.toFixed(1)}
              {latestRSI > 70 ? ' 과매수' : latestRSI < 30 ? ' 과매도' : ''}
            </span>
          </div>
        </div>
      )}

      {/* 일목균형표 안내 */}
      {indicators.includes('일목') && (
        <div className="card p-4 border-gold/20">
          <p className="text-xs text-gold">일목균형표는 데이터 최소 52일 필요 — 3달 이상 기간 선택 시 표시됩니다</p>
        </div>
      )}
    </div>
  )
}
