'use client'
import { useState, useEffect } from 'react'
import { ChevronRight, TrendingUp, TrendingDown, Minus } from 'lucide-react'
import { EARNINGS_WATCHLIST } from '@/lib/data'

const CATEGORIES = ['전체', '직접보유', 'AI인프라', '빅테크/반도체', '한국']

function BeatBadge({ surprisePct }) {
  if (surprisePct === null || surprisePct === undefined) return null
  if (surprisePct > 0) return (
    <span className="flex items-center gap-0.5 text-xs font-medium text-up bg-up/10 px-2 py-0.5 rounded-full">
      <TrendingUp size={10} /> BEAT +{surprisePct.toFixed(1)}%
    </span>
  )
  if (surprisePct < 0) return (
    <span className="flex items-center gap-0.5 text-xs font-medium text-down bg-down/10 px-2 py-0.5 rounded-full">
      <TrendingDown size={10} /> MISS {surprisePct.toFixed(1)}%
    </span>
  )
  return <span className="text-xs text-muted">IN-LINE</span>
}

function EarningCard({ stock }) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [expanded, setExpanded] = useState(false)

  useEffect(() => {
    if (expanded && !data) {
      setLoading(true)
      fetch(`/api/earnings?ticker=${stock.ticker}`)
        .then(r => r.json())
        .then(d => setData(d))
        .catch(() => {})
        .finally(() => setLoading(false))
    }
  }, [expanded, stock.ticker, data])

  const latest = data?.earningsHistory?.[0]
  const nextDate = data?.earningsDate

  return (
    <div className="card overflow-hidden">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full p-4 flex items-center justify-between active:bg-border/20"
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-surface border border-border flex items-center justify-center">
            <span className="text-xs font-bold font-mono text-accent">{stock.ticker.slice(0, 4)}</span>
          </div>
          <div className="text-left">
            <p className="text-sm font-semibold">{stock.name}</p>
            <p className="text-xs text-muted">{stock.category} {stock.weight ? `· ETF비중 ${stock.weight}%` : ''}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {latest && <BeatBadge surprisePct={latest.surprisePct} />}
          <ChevronRight size={16} className={`text-muted transition-transform ${expanded ? 'rotate-90' : ''}`} />
        </div>
      </button>

      {expanded && (
        <div className="border-t border-border p-4">
          {loading && (
            <div className="flex justify-center py-4">
              <div className="w-6 h-6 border-2 border-accent border-t-transparent rounded-full animate-spin" />
            </div>
          )}

          {!loading && data && (
            <div className="flex flex-col gap-4">
              {/* 다음 어닝 날짜 */}
              {nextDate && (
                <div className="flex items-center justify-between bg-accent/10 rounded-xl p-3">
                  <span className="text-xs text-muted">다음 어닝 예정</span>
                  <span className="text-sm font-semibold text-accent">{nextDate}</span>
                </div>
              )}

              {/* 최근 실적 히스토리 */}
              {data.earningsHistory?.length > 0 && (
                <div>
                  <p className="text-xs text-muted mb-2">분기별 EPS 실적</p>
                  <div className="flex flex-col gap-2">
                    {data.earningsHistory.slice(0, 4).map((h, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <span className="text-xs text-muted w-20">{h.date}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted">예상 ${h.epsEstimate?.toFixed(2)}</span>
                          <span className={`text-xs font-semibold font-num ${h.epsDiff >= 0 ? 'text-up' : 'text-down'}`}>
                            실제 ${h.epsActual?.toFixed(2)}
                          </span>
                          <BeatBadge surprisePct={h.surprisePct} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* EPS 트렌드 바 차트 */}
              {data.quarterlyEPS?.length > 0 && (
                <div>
                  <p className="text-xs text-muted mb-2">EPS 트렌드</p>
                  <div className="flex items-end gap-2 h-16">
                    {data.quarterlyEPS.slice(-6).map((q, i) => {
                      const maxEPS = Math.max(...data.quarterlyEPS.map(x => Math.abs(x.actual || 0)))
                      const h = maxEPS > 0 ? ((Math.abs(q.actual || 0) / maxEPS) * 100) : 10
                      return (
                        <div key={i} className="flex flex-col items-center gap-1 flex-1">
                          <div className="w-full flex flex-col justify-end" style={{ height: 48 }}>
                            <div
                              className={`w-full rounded-t-sm transition-all ${q.actual >= 0 ? 'bg-up/60' : 'bg-down/60'}`}
                              style={{ height: `${h}%` }}
                            />
                          </div>
                          <span className="text-[9px] text-muted">{q.date}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {!loading && !data && (
            <p className="text-xs text-muted text-center py-2">데이터를 불러올 수 없습니다</p>
          )}
        </div>
      )}
    </div>
  )
}

export default function EarningsTab() {
  const [category, setCategory] = useState('전체')

  const filtered = EARNINGS_WATCHLIST.filter(s =>
    category === '전체' || s.category === category
  )

  return (
    <div className="flex flex-col gap-4 p-4 animate-fade-in">
      <h2 className="text-lg font-semibold pt-2">어닝 트래커</h2>

      {/* 카테고리 필터 */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setCategory(cat)}
            className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              category === cat ? 'bg-accent text-white' : 'bg-surface border border-border text-muted'
            }`}
          >{cat}</button>
        ))}
      </div>

      <p className="text-xs text-muted">종목 클릭 시 어닝 상세 정보 로드</p>

      {/* 어닝 카드 목록 */}
      <div className="flex flex-col gap-2">
        {filtered.map(stock => (
          <EarningCard key={stock.ticker} stock={stock} />
        ))}
      </div>
    </div>
  )
}
