'use client'
import { useState, useEffect } from 'react'
import { RefreshCw, TrendingUp, TrendingDown, DollarSign, Coins } from 'lucide-react'
import { useQuotes, calcPortfolio } from '@/lib/useQuotes'
import { ACCOUNTS, THEME_MAP } from '@/lib/data'
import { fmtBigKRW, fmtKRW, fmtPct, colorClass } from '@/lib/fmt'

function Shimmer({ className }) {
  return <div className={`shimmer ${className}`} />
}

function StatCard({ label, value, sub, color }) {
  return (
    <div className="card p-4 flex flex-col gap-1">
      <span className="text-xs text-muted">{label}</span>
      <span className={`text-lg font-semibold font-num ${color || ''}`}>{value}</span>
      {sub && <span className="text-xs text-muted">{sub}</span>}
    </div>
  )
}

export default function HomeTab({ onNavigate }) {
  const { quotes, fx, loading, lastUpdated, refresh } = useQuotes()
  const [refreshing, setRefreshing] = useState(false)

  const { accountsSummary, totalKRW, totalGain, totalGainPct } = calcPortfolio(ACCOUNTS, quotes, fx)

  // 오늘 손익 계산 (changePct 기반)
  const todayGain = accountsSummary.reduce((sum, acc) => {
    return sum + acc.holdings.reduce((s, h) => {
      const dayGain = h.currentValueKRW * (h.changePct / 100) / (1 + h.changePct / 100)
      return s + dayGain
    }, 0)
  }, 0)

  const handleRefresh = async () => {
    setRefreshing(true)
    await refresh()
    setRefreshing(false)
  }

  // 테마별 수익률 계산
  const themePerf = Object.entries(THEME_MAP).map(([theme, { color, tickers }]) => {
    let totalVal = 0, totalCost = 0
    accountsSummary.forEach(acc => {
      acc.holdings.forEach(h => {
        if (tickers.includes(h.ticker)) {
          totalVal += h.currentValueKRW
          totalCost += h.costKRW
        }
      })
    })
    const pct = totalCost > 0 ? ((totalVal - totalCost) / totalCost) * 100 : 0
    return { theme, color, pct, totalVal }
  })

  return (
    <div className="flex flex-col gap-4 p-4 animate-fade-in">
      {/* 헤더 */}
      <div className="flex items-center justify-between pt-2">
        <div>
          <p className="text-xs text-muted">총 자산</p>
          <h1 className="text-3xl font-bold font-num grad-text">
            {loading ? <Shimmer className="w-40 h-8 inline-block" /> : fmtBigKRW(totalKRW)}
          </h1>
        </div>
        <button
          onClick={handleRefresh}
          className="p-2 rounded-full bg-surface border border-border active:scale-95 transition-transform"
        >
          <RefreshCw size={16} className={`text-muted ${refreshing ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* 수익 요약 */}
      <div className="card p-4 glow-accent">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-xs text-muted mb-1">총 평가손익</p>
            <p className={`text-xl font-bold font-num ${colorClass(totalGain)}`}>
              {loading ? <Shimmer className="w-32 h-6 inline-block" /> : (totalGain >= 0 ? '+' : '') + fmtKRW(totalGain) + '원'}
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted mb-1">수익률</p>
            <p className={`text-xl font-bold font-num ${colorClass(totalGainPct)}`}>
              {loading ? <Shimmer className="w-20 h-6 inline-block" /> : fmtPct(totalGainPct)}
            </p>
          </div>
        </div>
        <div className="mt-3 pt-3 border-t border-border flex justify-between items-center">
          <div>
            <p className="text-xs text-muted">오늘 손익</p>
            <p className={`text-sm font-semibold font-num ${colorClass(todayGain)}`}>
              {loading ? '—' : (todayGain >= 0 ? '+' : '') + fmtKRW(todayGain) + '원'}
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted">USD/KRW</p>
            <p className="text-sm font-semibold font-num text-gold">
              {fx.usdkrw?.toLocaleString('ko-KR', { maximumFractionDigits: 0 })}
              <span className={`text-xs ml-1 ${colorClass(fx.changePct)}`}>{fmtPct(fx.changePct, 2)}</span>
            </p>
          </div>
        </div>
      </div>

      {/* 환율 영향 */}
      <div className="card p-4">
        <p className="text-xs text-muted mb-2 flex items-center gap-1">
          <DollarSign size={12} /> 환율 1원 변동 시 자산 영향
        </p>
        {(() => {
          const usdAssets = accountsSummary.find(a => a.id === 'super365_us')
          const usdTotalKRW = usdAssets?.totalValue || 0
          const impactPer1Won = usdTotalKRW / (fx.usdkrw || 1380)
          return (
            <div className="flex justify-between">
              <span className="text-sm font-num text-up">+1원 → +{fmtKRW(impactPer1Won)}원</span>
              <span className="text-sm font-num text-down">-1원 → -{fmtKRW(impactPer1Won)}원</span>
            </div>
          )
        })()}
      </div>

      {/* 계좌별 미니 카드 */}
      <div>
        <p className="text-xs text-muted mb-2">계좌별 현황</p>
        <div className="flex flex-col gap-2">
          {accountsSummary.map(acc => (
            <button
              key={acc.id}
              onClick={() => onNavigate('portfolio')}
              className="card p-3 flex items-center justify-between active:scale-98 transition-transform"
            >
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: acc.color }} />
                <div className="text-left">
                  <p className="text-sm font-medium">{acc.name}</p>
                  <p className="text-xs text-muted">{acc.broker}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-semibold font-num">{fmtKRW(acc.totalValue)}원</p>
                {!acc.isCash && (
                  <p className={`text-xs font-num ${colorClass(acc.gainPct)}`}>{fmtPct(acc.gainPct)}</p>
                )}
                {acc.isCash && <p className="text-xs text-muted">연 {acc.rate}%</p>}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* 테마 히트맵 */}
      <div>
        <p className="text-xs text-muted mb-2">테마별 수익률</p>
        <div className="grid grid-cols-3 gap-2">
          {themePerf.map(({ theme, color, pct }) => {
            const intensity = Math.min(Math.abs(pct) / 20, 1)
            const bgColor = pct >= 0
              ? `rgba(34,197,94,${0.1 + intensity * 0.3})`
              : `rgba(239,68,68,${0.1 + intensity * 0.3})`
            return (
              <div
                key={theme}
                className="heatmap-cell rounded-xl p-3 text-center"
                style={{ background: bgColor, border: `1px solid ${pct >= 0 ? 'rgba(34,197,94,0.2)' : 'rgba(239,68,68,0.2)'}` }}
              >
                <p className="text-[10px] text-muted mb-1">{theme}</p>
                <p className={`text-sm font-bold font-num ${colorClass(pct)}`}>{fmtPct(pct, 1)}</p>
              </div>
            )
          })}
        </div>
      </div>

      {/* 업데이트 시간 */}
      {lastUpdated && (
        <p className="text-center text-xs text-muted pb-2">
          {lastUpdated.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })} 기준
        </p>
      )}
    </div>
  )
}
