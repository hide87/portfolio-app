'use client'
import { useState } from 'react'
import { Lock, TrendingUp, TrendingDown } from 'lucide-react'
import { useQuotes, calcPortfolio } from '@/lib/useQuotes'
import { ACCOUNTS } from '@/lib/data'
import { fmtKRW, fmtBigKRW, fmtPct, colorClass } from '@/lib/fmt'
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts'

const COLORS = ['#6366f1', '#22c55e', '#f59e0b', '#8b5cf6', '#ec4899', '#14b8a6']

export default function PortfolioTab() {
  const { quotes, fx, loading } = useQuotes()
  const { accountsSummary, totalKRW } = calcPortfolio(ACCOUNTS, quotes, fx)
  const [selectedAcc, setSelectedAcc] = useState('all')

  const currentAcc = selectedAcc === 'all'
    ? { holdings: accountsSummary.flatMap(a => a.holdings), totalValue: totalKRW }
    : accountsSummary.find(a => a.id === selectedAcc)

  // 파이차트 데이터
  const pieData = accountsSummary.map(acc => ({
    name: acc.name,
    value: acc.totalValue,
  }))

  return (
    <div className="flex flex-col gap-4 p-4 animate-fade-in">
      <h2 className="text-lg font-semibold pt-2">포트폴리오</h2>

      {/* 계좌 탭 */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        <button
          onClick={() => setSelectedAcc('all')}
          className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
            selectedAcc === 'all' ? 'bg-accent text-white' : 'bg-surface border border-border text-muted'
          }`}
        >전체</button>
        {accountsSummary.map(acc => (
          <button
            key={acc.id}
            onClick={() => setSelectedAcc(acc.id)}
            className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              selectedAcc === acc.id ? 'text-white' : 'bg-surface border border-border text-muted'
            }`}
            style={selectedAcc === acc.id ? { backgroundColor: acc.color } : {}}
          >{acc.name}</button>
        ))}
      </div>

      {/* 파이차트 (전체 선택 시) */}
      {selectedAcc === 'all' && (
        <div className="card p-4">
          <p className="text-xs text-muted mb-2">자산 배분</p>
          <div className="flex items-center gap-4">
            <div className="w-32 h-32">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={30} outerRadius={55} paddingAngle={3} dataKey="value">
                    {pieData.map((_, i) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-col gap-1.5">
              {accountsSummary.map((acc, i) => (
                <div key={acc.id} className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  <span className="text-xs text-muted">{acc.name}</span>
                  <span className="text-xs font-num ml-auto">{totalKRW > 0 ? ((acc.totalValue / totalKRW) * 100).toFixed(1) : 0}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 계좌 요약 (특정 계좌 선택 시) */}
      {selectedAcc !== 'all' && (() => {
        const acc = accountsSummary.find(a => a.id === selectedAcc)
        if (!acc) return null
        return (
          <div className="card p-4" style={{ borderColor: acc.color + '40' }}>
            <div className="flex justify-between">
              <div>
                <p className="text-xs text-muted">평가금액</p>
                <p className="text-xl font-bold font-num">{fmtBigKRW(acc.totalValue)}</p>
              </div>
              {!acc.isCash && (
                <div className="text-right">
                  <p className="text-xs text-muted">평가손익</p>
                  <p className={`text-lg font-bold font-num ${colorClass(acc.gain)}`}>
                    {acc.gain >= 0 ? '+' : ''}{fmtKRW(acc.gain)}원
                  </p>
                  <p className={`text-xs font-num ${colorClass(acc.gainPct)}`}>{fmtPct(acc.gainPct)}</p>
                </div>
              )}
            </div>
            {acc.isLocked && (
              <div className="mt-2 flex items-center gap-1 text-xs text-gold">
                <Lock size={12} /> 락업: {acc.lockUntil}까지
              </div>
            )}
          </div>
        )
      })()}

      {/* 종목 리스트 */}
      <div className="flex flex-col gap-2">
        {currentAcc?.holdings?.map((h, i) => (
          <div key={`${h.ticker}-${i}`} className="card p-4">
            <div className="flex justify-between items-start mb-2">
              <div>
                <p className="text-sm font-semibold">{h.name}</p>
                <p className="text-xs text-muted font-mono">{h.ticker} · {h.qty}주</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-semibold font-num">
                  {fmtKRW(h.currentValueKRW)}원
                </p>
                <p className={`text-xs font-num ${colorClass(h.changePct)}`}>
                  오늘 {fmtPct(h.changePct)}
                </p>
              </div>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted">
                평균단가 {fmtKRW(h.avgPrice)}원
              </span>
              <span className={`font-num font-medium ${colorClass(h.gainPct)}`}>
                {h.gain >= 0 ? '+' : ''}{fmtKRW(h.gain)}원 ({fmtPct(h.gainPct)})
              </span>
            </div>
            {/* 수익률 바 */}
            <div className="mt-2 h-1 bg-border rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${h.gainPct >= 0 ? 'bg-up' : 'bg-down'}`}
                style={{ width: `${Math.min(Math.abs(h.gainPct) * 3, 100)}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
