'use client'
import { Home, PieChart, TrendingUp, Calendar, Sparkles } from 'lucide-react'

const TABS = [
  { id: 'home', label: '홈', Icon: Home },
  { id: 'portfolio', label: '포트폴리오', Icon: PieChart },
  { id: 'chart', label: '차트', Icon: TrendingUp },
  { id: 'earnings', label: '어닝', Icon: Calendar },
  { id: 'ai', label: 'AI분석', Icon: Sparkles },
]

export default function TabBar({ activeTab, onTabChange }) {
  return (
    <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-surface/95 backdrop-blur-xl border-t border-border tab-safe z-50">
      <div className="flex items-center justify-around px-2 pt-2 pb-1">
        {TABS.map(({ id, label, Icon }) => {
          const active = activeTab === id
          return (
            <button
              key={id}
              onClick={() => onTabChange(id)}
              className="flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-all duration-200 active:scale-95"
            >
              <div className={`p-1.5 rounded-lg transition-all duration-200 ${active ? 'bg-accent/20' : ''}`}>
                <Icon
                  size={20}
                  className={active ? 'text-accent' : 'text-muted'}
                  strokeWidth={active ? 2.5 : 1.8}
                />
              </div>
              <span className={`text-[10px] font-medium transition-colors ${active ? 'text-accent' : 'text-muted'}`}>
                {label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
